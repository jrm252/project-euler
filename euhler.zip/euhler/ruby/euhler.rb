
def problem1
    sum = 0
    (1...1000)
        .select {|num| num%3==0 || num%5==0}
        .each do |num|    
            sum += num
        end
    p sum
end

def problem2
    sumEven = 0
    fib = [1,2]
    
    1000.times do
        fib << fib[-2] + fib[-1]
        next unless fib[-1] + fib[-2] >= 4000000
        break
    end

    fib
        .select {|num| num%2==0}
        .each do |num|
            if(num%2==0)
                sumEven+= num
            end
        end

    p sumEven
end

def isPrime(num)
    maxFactor = (num**0.5).floor
    (2..maxFactor).each do |x|
        if(num % x == 0)
            return false
        end
    end

    return true
end

def problem3
    # The prime factors of 13195 are 5, 7, 13 and 29.
    # What is the largest prime factor of the number 600851475143 ?

    num = 600851475143
    factors = (2..(num**0.5).floor).select{|x| num % x ==0}    
    primeFactors = factors.select {|x| isPrime(x) }
    p primeFactors.max
end

def isPalindrome(num)
    strNumber = num.to_s
    if(strNumber.reverse == strNumber)
        return true
    end

    return false
end

def problem4
    maxPalindrome = -1
    (100..999).each do |x|
        (100..999).each do |y|
            product = x*y
            if( isPalindrome(product))
                if(product > maxPalindrome)
                    maxPalindrome = product
                end
            end
        end
    end
    p maxPalindrome
end

def problem5
    p 2 * 2 * 2 * 2 * 3 * 3 * 5 * 7 * 11 * 13 * 17 * 19
end

def problem6
    # Find the difference between the sum of the squares 
    # of the first one hundred natural numbers and the square of the sum.
    sumOfSquares = 0
    (1..100).each do |x| 
        sumOfSquares = sumOfSquares + (x ** 2)
    end
    
    squareOfSum = 0
    (1..100).each do |x|
        squareOfSum = squareOfSum + x
    end
    squareOfSum = squareOfSum ** 2

    p squareOfSum - sumOfSquares 
end

def problem7
    # By listing the first six prime numbers: 2, 3, 5, 7, 11, and 13, we can see that the 6th prime is 13.
    # What is the 10 001st prime number?

    prime = 2
    nextPrime = -1
    (2..10001).each do |primeIndex|
        nextPrime = prime+1
        until isPrime(nextPrime)
            nextPrime = nextPrime + 1
        end
        prime = nextPrime
    end
    p prime
end

def problem8
    num = "7316717653133062491922511967442657474235534919493496983520312774506326239578318016984801869478851843858615607891129494954595017379583319528532088055111254069874715852386305071569329096329522744304355766896648950445244523161731856403098711121722383113622298934233803081353362766142828064444866452387493035890729629049156044077239071381051585930796086670172427121883998797908792274921901699720888093776657273330010533678812202354218097512545405947522435258490771167055601360483958644670632441572215539753697817977846174064955149290862569321978468622482839722413756570560574902614079729686524145351004748216637048440319989000889524345065854122758866688116427171479924442928230863465674813919123162824586178664583591245665294765456828489128831426076900422421902267105562632111110937054421750694165896040807198403850962455444362981230987879927244284909188845801561660979191338754992005240636899125607176060588611646710940507754100225698315520005593572972571636269561882670428252483600823257530420752963450"
    maxProduct = -1
    (0..987).each do |index|
        product = 1
        (0..12).each do |pos|            
            product = product * num[index + pos].to_i
        end            
        if(product > maxProduct)
            maxProduct = product
        end
    end
    
    p maxProduct
end

def problem9
    (1..1000).each do |c|
        (1..999).each do |b|
            a = 1000 - b - c
            if(a * a + b * b == c * c)                
                p (a * b * c)
                return
            end
        end
    end    
end

def problem10
    prime = 2
    nextPrime = -1
    sum = 0
    until nextPrime >= 2000000 
        sum = sum + prime
        nextPrime = prime+1
        until isPrime(nextPrime)
            nextPrime = nextPrime + 1
        end
        prime = nextPrime       
    end
    p sum
end

#problem1
#problem2
#problem3
#problem4
#problem5
#problem6
#problem7
#problem8
#problem9
#problem10