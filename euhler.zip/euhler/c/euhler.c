
#include <stdio.h>
#include <math.h>
#include <stdbool.h>

bool isPrime(long num)
{
    double dblNumSqrt = sqrt((double)num);
    long numSqrt = (long) floor(dblNumSqrt);

    for(int divisor = 2; divisor <= numSqrt; divisor++)
    {
        if(num % divisor == 0)
        {
            return false;
        }
    }
    return true;
}

int getLength(char *string)
{
    int length = 0;

    while(string[length] != '\0')   // if position x isn't null terminating char
    {
        length++;                   // length is at least x + 1
    }
    return length;
}

bool isPalindrome(int num)
{
    char strNum[12];
    sprintf(strNum, "%d", num);
    int length = getLength(strNum);
    int index = 0;
    for(index = 0; index < length; index++)
    {
        if(strNum[index] != strNum[length - index - 1])
        {
            return false;
        }
    }
    return true;        
}

void problem1()
{
    long max = 990;
    long num = 0;
    long sum = 0;

    while(true)
    {
        num++;  // 1 (or 15n + 1)
        
        num++;  // 2 (or 15n + 2)
        
        num++;  // 3 (or 15n + 3)       
        sum+=num;
        
        num++;  // 4 (or 15n + 4)
        
        num++;  // 5 (or 15n + 5)
        sum+=num;
        
        num++;  // 6 (or 15n + 6)
        sum+=num;
        
        num++;  // 7 (or 15n + 7)
        
        num++;  // 8 (or 15n + 8)
        
        num++;  // 9 (or 15n + 9)
        sum+=num;
        
        num++;  // 10 (or 15n + 10)
        sum+=num;
        
        num++;  // 11 (or 15n + 11)
        
        num++;  // 12 (or 15n + 12)
        sum+=num;
        
        num++;  // 13 (or 15n + 13)
        
        num++;  // 14 (or 15n + 14)
        
        num++;  // 15 (or 15n + 15)
        sum+=num;
        
        if(num >=max)
        {
            break;
        }
    }

     num++;  // 1 (or 15n + 1)
        
        num++;  // 2 (or 15n + 2)
        
        num++;  // 3 (or 15n + 3)       
        sum+=num;
        
        num++;  // 4 (or 15n + 4)
        
        num++;  // 5 (or 15n + 5)
        sum+=num;
        
        num++;  // 6 (or 15n + 6)
        sum+=num;
        
        num++;  // 7 (or 15n + 7)
        
        num++;  // 8 (or 15n + 8)
        
        num++;  // 9 (or 15n + 9)
        sum+=num;
        
        num++;  // 10 (or 15n + 10)
        sum+=num;

          printf("Problem 1: %20ld\r\n", sum);
}

void problem2()
{
    long maxFib = 4000000;
    long fib1 = 1;
    long fib2 = 2;
    long nextFib = 0;
    long sum = fib2; //2 is the first even fibonacci number

    while(true)
    {
        nextFib = fib1+fib2;
        if(nextFib > maxFib)
        {
            break;
        }

        if(nextFib % 2 ==0)
        {
            sum += nextFib;
        }        

        fib1 = fib2;
        fib2 = nextFib;
    }

    printf("Problem 2: %20ld\r\n", sum);
}
void problem3()
{
    long num = 600851475143;
    double dblNumSqrt = sqrt((double)num);
    long numSqrt = (long) floor(dblNumSqrt);
    long factors[1000];
    int factorsIndex = 0;

    for (long testFactor = 2; testFactor <= numSqrt; testFactor++)
    {
        if(num % testFactor == 0)
        {
            //Factor
             factors[factorsIndex++] = testFactor; 

             if(factorsIndex>=1000)
             {
                 printf("Increase size of factors[] array");
             }          
        }
    }
    factorsIndex;

    long maxPrimeFactor = 1;

    for(int index = 0; index < factorsIndex; index++)
    {
        if(isPrime(factors[index]))
        {
            maxPrimeFactor = factors[index];
        }
    }
    
    printf("Problem 3: %20ld\r\n", maxPrimeFactor);
}

void problem4()
{
    // A palindromic number reads the same both ways. 
    // The largest palindrome made from the product of two 2-digit numbers is 9009 = 91 × 99.
    // Find the largest palindrome made from the product of two 3-digit numbers.

    int num1 = 0;
    int num2 = 0;
    int product = 0;
    int largestPalindrome = 0;

    for(int num1 = 900; num1 < 1000; num1++)
    {
        for(int num2 = 900; num2 < 1000; num2+=3)
        {
            product = num1 * num2;
            if(isPalindrome(product))
            {
                if(product > largestPalindrome)
                {
                    largestPalindrome = product;
                }
            }
        }
    } 
    printf("Problem 4: %20d\r\n", largestPalindrome);
}

void problem5()
{
    long num = 1 * 2 * 2 * 2 * 2 * 3 * 3 * 5 * 7 * 11 * 13 * 17 * 19;

    printf("Problem 5: %20ld\r\n", num);
}

int main()
{
    problem1();
    problem2();
    problem3();
    problem4();
    problem5();

    return 0;   //Exit gracefully
}