
def problem1
    sum = 0
    (1...1000)
        .select {|num| num%3==0 || num%5==0}
        .each do |num|    
            sum += num
        end
    p sum
end

def problem2
    sumEven = 0
    fib = [1,2]
    
    1000.times do
        fib << fib[-2] + fib[-1]
        next unless fib[-1] + fib[-2] >= 4000000
        break
    end

    fib
        .select {|num| num%2==0}
        .each do |num|
            if(num%2==0)
                sumEven+= num
            end
        end

    p sumEven
end

def isPrime(num)
    maxFactor = (num**0.5).floor
    p maxFactor
    2..maxFactor do |x|
        if(num % x == 0)
            return false
        end
    end

    return true
end

def problem3
    # The prime factors of 13195 are 5, 7, 13 and 29.
    # What is the largest prime factor of the number 600851475143 ?

    num = 600851475143
    factors = (2..(num**0.5).floor).select{|x| num % x ==0}
    p factors
    primeFactors = factors.select {|x| isPrime(x) }
    p primeFactors.max
end

problem1
problem2
problem3